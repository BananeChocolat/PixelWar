# PixelWar


"Apprenez à dompter la machine"

To do :
- [ ] Terminer partie serveur ( 2ème serveur qui gère le csv)
- [ ] Faire le script python qui gère intégration du csv (lien entre page et serveurs)
- [ ] Optimiser serveur (envoyer que la modification et non pas la grille entière à chaque fois)
- [ ] Patch bug zoom ( les coordonnées tendent vers 500 quand on zoom)
- [ ] Patch tous les bugs mineurs
- [ ] Setup les serveurs et heberger une version bêta du site online
- [ ] Ajouter des sécurités pour éviter bots  
- [ ] Recupérer la grille non pas grace aux requêtes python mais grâce à une api   
- [ ] Clean site entier
